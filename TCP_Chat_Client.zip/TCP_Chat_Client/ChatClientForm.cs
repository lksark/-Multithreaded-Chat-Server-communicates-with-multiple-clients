﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.IO;

namespace TCP_Chat
{
    public partial class ChatClientForm : Form
    {
        public ChatClientForm()
        {
            InitializeComponent();
        }

        private TcpClient client;
        private NetworkStream output;           // stream for receiving data
        private BinaryWriter writer;            // facilitates writing to the stream
        private BinaryReader reader;            // facilitates reading from the stream
        private Thread readThread;              // Thread for processing incoming messages
        private string message = "";
        int port_number;

        // initialize thread for reading
        private void ChatClientForm_Load(object sender, EventArgs e)
        {
            port_number = 50000;

            readThread = new Thread(new ThreadStart(RunClient));
            readThread.Start();
        }

        // close all threads associated with this application
        private void ChatClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (client.Connected)
                writer.Write("CLIENT>>> TERMINATE");

            System.Environment.Exit(System.Environment.ExitCode);
        }

        // delegate that allows method DisplayMessage to be called in the thread that creates and maintains the GUI
        private delegate void DisplayDelegate(string message);

        // method DisplayMessage sets displayTextBox's Text property in a thread-safe manner
        private void DisplayMessage(string message)
        {
            // if modifying displayTextBox is not thread safe
            if (displayTextBox.InvokeRequired)
            {
                // use inherited method Invoke to execute DisplayMessage via a delegate
                Invoke(new DisplayDelegate(DisplayMessage), new object[] { message });
            }
            else    // OK to modify displayTextBox in current thread
            {
                displayTextBox.Text += message;

                displayTextBox.SelectionStart = displayTextBox.Text.Length;
                displayTextBox.ScrollToCaret();
                displayTextBox.Refresh();
            }
        }

        // delegate that allows method DisableInput to be called in the thread that creates and maintains the GUI
        private delegate void DisableInputDelegate(bool value);

        // method DisableInput sets inputTextBox's ReadOnly property in a thread-safe manner
        private void DisableInput(bool value)
        {
            // if modifying inputTextBox is not thread safe
            if (inputTextBox.InvokeRequired)
            {
                // use inherited method Invoke to execute DisableInput via a delegate
                Invoke(new DisableInputDelegate(DisableInput), new object[] { value });
            }
            else  // OK to modify inputTextBox in current thread
                inputTextBox.ReadOnly = value;
        }

        // sends text the user typed to server
        private void inputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter && inputTextBox.ReadOnly == false)
                {
                    if (client.Connected && inputTextBox.Text != "")
                    {
                        writer.Write("CLIENT" + port_number + ">>> " + inputTextBox.Text);
                        displayTextBox.Text += "\r\nCLIENT>>> " + inputTextBox.Text;
                        displayTextBox.SelectionStart = displayTextBox.Text.Length;
                        displayTextBox.ScrollToCaret();
                        displayTextBox.Refresh();
                    }

                    inputTextBox.Clear();
                }
            }
            catch (SocketException)
            {
                displayTextBox.Text += "\nError writing object";
            }
        }

        // connect to server and display server-generated text
        private void RunClient()
        {

            int retry_count = 0;
            int HandshakeCode = 0;

            while (port_number == 50000 && retry_count < 3)
            {
                try
                {
                    DisplayMessage("\r\nAttempting connection\r\n");

                    // Step 1: Create TcpClient and connect to server
                    client = new TcpClient();
                    client.Connect("127.0.0.1", port_number);

                    // Step 2: get NetworkStream associated with TcpClient
                    output = client.GetStream();

                    // create objects for writing and reading across stream
                    writer = new BinaryWriter(output);
                    reader = new BinaryReader(output);

                    DisplayMessage("\r\nGot I/O streams from port " + port_number + "\r\n");

                    // loop until server signals termination
                    do
                    {
                        // Step 3: processing phase
                        try
                        {
                            // read message from server
                            message = reader.ReadString();
                            DisplayMessage("\r\n" + message);
                        }
                        catch (Exception)
                        {
                            // handle exception if error in reading server data
                            //System.Environment.Exit(System.Environment.ExitCode);
                            DisplayMessage("\r\nError in reading server data\r\n");
                            Thread.Sleep(1000);
                        }
                    } while (message != "SERVER>>> TERMINATE" && !message.StartsWith("SERVER>>>Port=>") && !message.Equals("SERVER>>> FULL"));

                    // Step 4: close connection
                    writer.Close();
                    reader.Close();
                    output.Close();
                    client.Close();

                    if (message.StartsWith("SERVER>>>Port=>"))
                    {
                        string[] connection_parameters = message.Split(',');

                        connection_parameters[0] = connection_parameters[0].Remove(0, 15);
                        port_number = int.Parse(connection_parameters[0]);

                        connection_parameters[1] = connection_parameters[1].Remove(0, 14);
                        HandshakeCode = int.Parse(connection_parameters[1]);
                    }

                    if (message == "SERVER>>> FULL")
                    {
                        DisplayMessage("\r\nServer full. Will retry 2 seconds later.\r\n");
                        Thread.Sleep(2000);
                    }

                    //Application.Exit();
                }
                catch (Exception error)
                {
                    // handle exception if error in establishing connection
                    //MessageBox.Show(error.ToString(), "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DisplayMessage("\r\nConnection to portal server fail\r\n\n");
                    //System.Environment.Exit(System.Environment.ExitCode);
                    if (port_number == 50000)
                    {
                        retry_count++;
                        Thread.Sleep(1000);
                    }
                }
            }

            if (port_number == 50000)
                DisplayMessage("\r\n3 attempts to connect to portal server failed.\r\n");
            else
            {
                try
                {
                    DisplayMessage("\r\nAttempting connection\r\n");

                    // Step 1: Create TcpClient and connect to server
                    client = new TcpClient();
                    client.Connect("127.0.0.1", port_number);

                    // Step 2: get NetworkStream associated with TcpClient
                    output = client.GetStream();

                    // create objects for writing and reading across stream
                    writer = new BinaryWriter(output);
                    reader = new BinaryReader(output);

                    DisplayMessage("\r\nGot I/O streams from port " + port_number + "\r\n");
                    DisableInput(false);    // enable InputTextBox

                    //message = reader.ReadString();

                    writer.Write("CLIENT" + port_number + ">>>HandshakeCode=" + HandshakeCode);

                    // loop until server signals termination or server signals timeout
                    do
                    {
                        // Step 3: processing phase
                        try
                        {
                            // read message from server
                            message = reader.ReadString();
                            DisplayMessage("\r\n" + message + "\r\n");
                        }
                        catch (Exception)
                        {
                            // handle exception if error in reading server data
                            //System.Environment.Exit(System.Environment.ExitCode);
                            DisplayMessage("\r\nConnection Error\r\n");
                        }
                    } while (message != "SERVER>>> TERMINATE" && message != "SERVER>>> IDLE TIMEOUT" && message != "SERVER>>> TOTAL TIME TIMEOUT" && client.Connected);

                    // Step 4: close connection
                    writer.Close();
                    reader.Close();
                    output.Close();
                    client.Close();

                    //Application.Exit();
                }
                catch (Exception error)
                {
                    // handle exception if error in establishing connection
                    //MessageBox.Show(error.ToString(), "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DisplayMessage("\r\nConnection Error\r\n");
                    //System.Environment.Exit(System.Environment.ExitCode);
                }

                DisplayMessage("End of connection\r\n");
            }
        }
    }
}
